<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartTriage AI - Clinical Assistant</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
</head>

<body>

    <div class="loading-overlay" id="loadingOverlay">
        <div class="spinner"></div>
    </div>

    <div class="container">
        <header>
            <h1>SmartTriage AI</h1>
            <p>Advanced Clinical Decision Support System</p>
        </header>

        <div class="card">
            <h2>Patient Assessment Form</h2>
            <form id="triageForm">
                <!-- Patient Demographics -->
                <div class="form-grid">
                    <div class="form-group">
                        <label for="name">Patient Name</label>
                        <input type="text" id="name" name="name" required placeholder="John Doe">
                    </div>
                    <div class="form-group">
                        <label for="age">Age</label>
                        <input type="number" id="age" name="age" required placeholder="45">
                    </div>
                    <div class="form-group">
                        <label for="gender">Gender</label>
                        <select id="gender" name="gender" required>
                            <option value="">Select Gender</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="contact">Contact (Optional)</label>
                        <input type="text" id="contact" name="contact" placeholder="Phone or Email">
                    </div>
                </div>

                <!-- Vitals -->
                <div class="form-group">
                    <label>Vital Signs</label>
                </div>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="heart_rate">Heart Rate (bpm)</label>
                        <input type="number" id="heart_rate" name="heart_rate" placeholder="e.g. 80">
                    </div>
                    <div class="form-group">
                        <label for="bp_systolic">Systolic BP (mmHg)</label>
                        <input type="number" id="bp_systolic" name="bp_systolic" placeholder="e.g. 120">
                    </div>
                    <div class="form-group">
                        <label for="bp_diastolic">Diastolic BP (mmHg)</label>
                        <input type="number" id="bp_diastolic" name="bp_diastolic" placeholder="e.g. 80">
                    </div>
                    <div class="form-group">
                        <label for="temperature">Temperature (°C)</label>
                        <input type="number" step="0.1" id="temperature" name="temperature" placeholder="e.g. 37.0">
                    </div>
                    <div class="form-group">
                        <label for="respiratory_rate">Respiratory Rate (bpm)</label>
                        <input type="number" id="respiratory_rate" name="respiratory_rate" placeholder="e.g. 16">
                    </div>
                </div>

                <!-- Clinical Info -->
                <div class="form-group">
                    <label for="symptoms">Presenting Symptoms</label>
                    <textarea id="symptoms" name="symptoms" required placeholder="Describe what the patient is feeling..."></textarea>
                </div>

                <div class="form-group">
                    <label for="history">Medical History</label>
                    <textarea id="history" name="history" placeholder="Chronic illnesses, allergies, etc..."></textarea>
                </div>

                <button type="submit" class="btn-submit">Analyze & Triage</button>
            </form>
        </div>

        <!-- Results Section -->
        <div id="result-section" class="card">
            <h2>Triage Assessment Result</h2>

            <div style="text-align: center; margin-bottom: 2rem;">
                <div id="res-level" class="triage-badge"></div>
                <div id="severity-container" class="severity-meter">
                    <div id="severity-bar" class="severity-fill"></div>
                </div>
                <div style="display: flex; justify-content: space-between; font-size: 0.85rem; color: var(--secondary-color);">
                    <span>Routine</span>
                    <span>Urgent</span>
                    <span>Critical</span>
                </div>
            </div>

            <div class="info-grid">
                <div class="info-item">
                    <h4>Patient</h4>
                    <p id="res-name"></p>
                </div>
                <div class="info-item">
                    <h4>Demographics</h4>
                    <p><span id="res-age"></span> / <span id="res-gender"></span></p>
                </div>
                <div class="info-item">
                    <h4>Severity Score</h4>
                    <p id="res-score"></p>
                </div>
                <div class="info-item">
                    <h4>Recommended Tests</h4>
                    <ul id="res-tests" class="tests-list"></ul>
                </div>
            </div>

            <div class="ai-notes">
                <strong><i class="fas fa-robot"></i> AI Assessment Notes:</strong>
                <p id="res-notes" style="margin-top: 0.5rem;"></p>
            </div>
        </div>
    </div>

    <script src="assets/js/app.js"></script>
</body>

</html>