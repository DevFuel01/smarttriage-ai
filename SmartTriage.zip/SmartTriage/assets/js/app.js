
document.addEventListener('DOMContentLoaded', () => {
    const triageForm = document.getElementById('triageForm');
    const resultSection = document.getElementById('result-section');
    const loadingOverlay = document.getElementById('loadingOverlay');

    triageForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        // Basic Validation
        const age = parseInt(document.getElementById('age').value);
        if (age < 0 || age > 120) {
            alert('Please enter a valid age (0-120).');
            return;
        }

        const heartRate = parseInt(document.getElementById('heart_rate').value);
        if (heartRate && (heartRate < 30 || heartRate > 250)) {
            alert('Please enter a valid heart rate (30-250 bpm).');
            return;
        }

        const temp = parseFloat(document.getElementById('temperature').value);
        if (temp && (temp < 30 || temp > 45)) {
            alert('Please enter a valid temperature (30-45°C).');
            return;
        }
        
        // Show loading
        loadingOverlay.style.display = 'flex';
        resultSection.style.display = 'none';

        // Collect Data
        const formData = new FormData(triageForm);
        const data = {
            name: formData.get('name'),
            age: parseInt(formData.get('age')),
            gender: formData.get('gender'),
            contact: formData.get('contact'),
            symptoms: formData.get('symptoms'),
            vitals: {
                heart_rate: formData.get('heart_rate') + ' bpm',
                blood_pressure: formData.get('bp_systolic') + '/' + formData.get('bp_diastolic') + ' mmHg',
                temperature: formData.get('temperature') + '°C',
                respiratory_rate: formData.get('respiratory_rate') + ' bpm'
            },
            history: formData.get('history')
        };

        try {
            const response = await fetch('api/triage.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });

            if (!response.ok) {
                throw new Error('API Error');
            }

            const result = await response.json();
            displayResult(result);

        } catch (error) {
            console.error('Error:', error);
            alert('An error occurred while processing the triage. Please try again.');
        } finally {
            loadingOverlay.style.display = 'none';
        }
    });
});

function displayResult(data) {
    const resultSection = document.getElementById('result-section');
    
    // Update Fields
    document.getElementById('res-name').textContent = data.patient_name;
    document.getElementById('res-age').textContent = data.age;
    document.getElementById('res-gender').textContent = data.gender;
    document.getElementById('res-score').textContent = data.severity_score + '%';
    document.getElementById('res-notes').textContent = data.ai_notes;

    // Triage Level Styling
    const badge = document.getElementById('res-level');
    badge.textContent = data.triage_level + ' Priority';
    badge.className = 'triage-badge'; // Reset
    
    const severityBar = document.getElementById('severity-bar');
    severityBar.className = 'severity-fill'; // Reset
    setTimeout(() => {
        severityBar.style.width = data.severity_score + '%';
    }, 100);

    if (data.triage_level === 'Red') {
        badge.classList.add('triage-red');
        document.getElementById('severity-container').className = 'severity-meter severity-red';
    } else if (data.triage_level === 'Yellow') {
        badge.classList.add('triage-yellow');
        document.getElementById('severity-container').className = 'severity-meter severity-yellow';
    } else {
        badge.classList.add('triage-green');
        document.getElementById('severity-container').className = 'severity-meter severity-green';
    }

    // Recommended Tests
    const testsList = document.getElementById('res-tests');
    testsList.innerHTML = '';
    if (data.recommended_tests && data.recommended_tests.length > 0) {
        data.recommended_tests.forEach(test => {
            const li = document.createElement('li');
            li.textContent = test;
            testsList.appendChild(li);
        });
    } else {
        const li = document.createElement('li');
        li.textContent = 'None';
        testsList.appendChild(li);
    }

    // Show Result
    resultSection.style.display = 'block';
    
    // Scroll to result
    resultSection.scrollIntoView({ behavior: 'smooth' });
}
