
document.addEventListener('DOMContentLoaded', () => {
    fetchQueue();
    // Auto-refresh every 10 seconds
    setInterval(fetchQueue, 10000);

    // Modal Close Logic
    const modal = document.getElementById('detailsModal');
    const span = document.getElementsByClassName("close")[0];
    span.onclick = function() {
        modal.style.display = "none";
    }
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
});

async function fetchQueue() {
    try {
        const response = await fetch('api/fetch_queue.php');
        const data = await response.json();
        renderQueue(data.records);
    } catch (error) {
        console.error('Error fetching queue:', error);
    }
}

function renderQueue(patients) {
    const queueList = document.getElementById('queue-list');
    queueList.innerHTML = '';

    if (patients.length === 0) {
        queueList.innerHTML = '<div class="no-patients">No patients in queue.</div>';
        return;
    }

    patients.forEach(patient => {
        const card = document.createElement('div');
        card.className = `patient-card border-${patient.triage_level.toLowerCase()}`;
        
        // Vitals Summary (First item for quick view)
        // Accessing vitals object properties carefully
        let bp = 'N/A';
        let hr = 'N/A';
        if (patient.vitals) {
            // Depending on how it was saved, it might be an object or string. 
            // In API we did json_decode, so it should be an object.
            // But let's handle if it was doubly encoded.
            let v = patient.vitals;
            if (typeof v === 'string') {
                 try { v = JSON.parse(v); } catch(e){}
            }
            bp = v.blood_pressure || 'N/A';
            hr = v.heart_rate || 'N/A';
        }

        card.innerHTML = `
            <div class="card-header">
                <span class="patient-name">${patient.patient_name}</span>
                <span class="triage-tag tag-${patient.triage_level.toLowerCase()}">${patient.triage_level}</span>
            </div>
            <div class="card-body">
                <p><strong>Age/Gender:</strong> ${patient.age} / ${patient.gender}</p>
                <p><strong>Symptoms:</strong> ${truncate(patient.symptoms, 50)}</p>
                <div class="vital-preview">
                    <span><i class="fas fa-heartbeat"></i> ${hr}</span>
                    <span><i class="fas fa-tachometer-alt"></i> ${bp}</span>
                </div>
                <button class="btn-details" onclick='openModal(${JSON.stringify(patient).replace(/'/g, "&#39;")})'>View Details</button>
            </div>
            <div class="card-footer">
                <small>Assessed: ${new Date(patient.created_at).toLocaleTimeString()}</small>
                <small>Score: ${patient.severity_score}</small>
            </div>
        `;
        queueList.appendChild(card);
    });
}

function openModal(patient) {
    const modal = document.getElementById('detailsModal');
    
    document.getElementById('m-name').textContent = patient.patient_name;
    document.getElementById('m-details').textContent = `${patient.age} years / ${patient.gender}`;
    document.getElementById('m-contact').textContent = patient.contact_info || 'N/A';
    document.getElementById('m-symptoms').textContent = patient.symptoms;
    document.getElementById('m-history').textContent = patient.medical_history || 'None';
    
    // Vitals
    let vitalsHtml = '';
    // Handle vitals object double checks
    let v = patient.vitals;
    if (typeof v === 'string') try { v = JSON.parse(v); } catch(e){}
    
    if (v) {
        for (const [key, value] of Object.entries(v)) {
            vitalsHtml += `<li><strong>${key.replace('_', ' ')}:</strong> ${value}</li>`;
        }
    }
    document.getElementById('m-vitals').innerHTML = vitalsHtml;

    // AI Section
    document.getElementById('m-triage').textContent = patient.triage_level;
    document.getElementById('m-score').textContent = patient.severity_score;
    document.getElementById('m-notes').textContent = patient.ai_notes;

    // Remove old classes
    const triageBadge = document.getElementById('m-triage');
    triageBadge.className = 'triage-badge';
    triageBadge.classList.add(`triage-${patient.triage_level.toLowerCase()}`);

    // Recommended Tests
    let testsHtml = '';
    let t = patient.recommended_tests;
    if (typeof t === 'string') try { t = JSON.parse(t); } catch(e){}
    
    if (Array.isArray(t)) {
        t.forEach(test => testsHtml += `<li>${test}</li>`);
    } else {
        testsHtml = '<li>None</li>';
    }
    document.getElementById('m-tests').innerHTML = testsHtml;

    modal.style.display = "block";
}

function truncate(str, n){
    return (str.length > n) ? str.substr(0, n-1) + '&hellip;' : str;
}
