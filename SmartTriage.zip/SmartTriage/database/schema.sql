CREATE DATABASE IF NOT EXISTS smart_triage;
USE smart_triage;

CREATE TABLE IF NOT EXISTS patient_triage (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_name VARCHAR(255) NOT NULL,
    age INT NOT NULL,
    gender VARCHAR(50) NOT NULL,
    contact_info VARCHAR(255) DEFAULT NULL,
    symptoms TEXT NOT NULL,
    vitals JSON DEFAULT NULL,
    medical_history TEXT DEFAULT NULL,
    triage_level ENUM('Red', 'Yellow', 'Green') NOT NULL,
    severity_score INT NOT NULL,
    recommended_tests JSON DEFAULT NULL,
    ai_notes TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
