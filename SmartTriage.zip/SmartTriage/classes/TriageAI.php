<?php

class TriageAI
{
    private $apiKey;
    private $apiUrl;

    public function __construct()
    {
        $this->apiKey = GEMINI_API_KEY;
        $this->apiUrl = GEMINI_API_ENDPOINT . '?key=' . $this->apiKey;
    }

    public function assessPatient($patientData)
    {
        $prompt = $this->constructPrompt($patientData);

        $data = [
            "contents" => [
                [
                    "parts" => [
                        ["text" => $prompt]
                    ]
                ]
            ]
        ];

        $ch = curl_init($this->apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json'
        ]);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

        $response = curl_exec($ch);

        if (curl_errno($ch)) {
            return ['error' => 'Curl error: ' . curl_error($ch)];
        }

        curl_close($ch);

        return $this->processResponse($response);
    }

    private function constructPrompt($data)
    {
        return "
You are an AI assistant called SmartTriage AI designed to help remote clinics triage patients efficiently. 
Analyze the following patient data and provided a JSON output as specified.

Input Data:
Patient Name: {$data['name']}
Age: {$data['age']}
Gender: {$data['gender']}
Symptoms: {$data['symptoms']}
Vitals: " . json_encode($data['vitals']) . "
Medical History: {$data['history']}

Output Requirements:
Provide ONLY a valid JSON object with the following structure, no other text:
{
\"patient_name\": \"<Patient Name>\",
\"age\": <Age>,
\"gender\": \"<Gender>\",
\"triage_level\": \"<Red/Yellow/Green>\",
\"severity_score\": <0-100>,
\"recommended_tests\": [\"<Test1>\", \"<Test2>\", ...],
\"ai_notes\": \"<Explain why this triage was assigned and any key observations>\"
}

Guidelines:
- Categorize patient into Red (Critical), Yellow (Urgent), Green (Routine).
- Prioritize safety.
- For Green (Routine) patients, include brief home care advice or recommended over-the-counter remedies in the ai_notes.
";
    }

    private function processResponse($response)
    {
        $decoded = json_decode($response, true);

        if (isset($decoded['candidates'][0]['content']['parts'][0]['text'])) {
            $text = $decoded['candidates'][0]['content']['parts'][0]['text'];
            // Clean up potential markdown formatting from Gemini
            $text = str_replace(['```json', '```'], '', $text);
            return json_decode(trim($text), true);
        }

        return ['error' => 'Invalid response from AI', 'raw' => $response];
    }
}
