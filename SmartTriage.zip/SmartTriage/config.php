<?php

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'smart_triage');
define('DB_USER', 'root');
define('DB_PASS', '');

// Gemini API Configuration
// REPLACE WITH YOUR ACTUAL API KEY 
define('GEMINI_API_KEY', 'YOUR_API_KEY_HERE');
define('GEMINI_API_ENDPOINT', 'https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent');
