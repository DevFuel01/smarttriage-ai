<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include_once '../config.php';
include_once '../classes/Database.php';

$database = new Database();
$db = $database->getConnection();

// Custom sorting logic: Red > Yellow > Green, then by Time DESC
$query = "SELECT * FROM patient_triage 
          ORDER BY 
          CASE triage_level
            WHEN 'Red' THEN 1
            WHEN 'Yellow' THEN 2
            WHEN 'Green' THEN 3
            ELSE 4
          END ASC, 
          created_at DESC";

$stmt = $db->prepare($query);
$stmt->execute();

$num = $stmt->rowCount();

if ($num > 0) {
    $patients_arr = array();
    $patients_arr["records"] = array();

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        extract($row);

        $patient_item = array(
            "id" => $id,
            "patient_name" => $patient_name,
            "age" => $age,
            "gender" => $gender,
            "contact_info" => $contact_info,
            "symptoms" => html_entity_decode($symptoms),
            "vitals" => json_decode($vitals), // Already JSON in DB, but let's ensure it's usable
            "medical_history" => html_entity_decode($medical_history),
            "triage_level" => $triage_level,
            "severity_score" => $severity_score,
            "recommended_tests" => json_decode($recommended_tests),
            "ai_notes" => html_entity_decode($ai_notes),
            "created_at" => $created_at
        );

        array_push($patients_arr["records"], $patient_item);
    }

    http_response_code(200);
    echo json_encode($patients_arr);
} else {
    http_response_code(200); // Return 200 even if empty to handle "no patients" gracefully
    echo json_encode(array("records" => []));
}
