<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config.php';
include_once '../classes/Database.php';
include_once '../classes/TriageAI.php';

$database = new Database();
$db = $database->getConnection();

$data = json_decode(file_get_contents("php://input"), true);

if (
    !empty($data['name']) &&
    !empty($data['age']) &&
    !empty($data['gender']) &&
    !empty($data['symptoms'])
) {
    // 1. Get AI Assessment
    $triageAI = new TriageAI();
    $assessment = $triageAI->assessPatient($data);

    if (isset($assessment['error'])) {
        http_response_code(503);
        echo json_encode(["message" => "AI Service Unavailable.", "error" => $assessment['error']]);
        exit();
    }

    // 2. Save to Database
    $query = "INSERT INTO patient_triage 
              SET patient_name=:name, age=:age, gender=:gender, contact_info=:contact, symptoms=:symptoms, 
                  vitals=:vitals, medical_history=:history, 
                  triage_level=:level, severity_score=:score, 
                  recommended_tests=:tests, ai_notes=:notes";

    $stmt = $db->prepare($query);

    // Bind Patient Data
    $stmt->bindParam(":name", $data['name']);
    $stmt->bindParam(":age", $data['age']);
    $stmt->bindParam(":gender", $data['gender']);
    $stmt->bindParam(":contact", $data['contact']);
    $stmt->bindParam(":symptoms", $data['symptoms']);

    // Bind JSON Data
    $vitals_json = json_encode($data['vitals']);
    $history_text = $data['history'] ?? '';
    $stmt->bindParam(":vitals", $vitals_json);
    $stmt->bindParam(":history", $history_text);

    // Bind AI Results
    $stmt->bindParam(":level", $assessment['triage_level']);
    $stmt->bindParam(":score", $assessment['severity_score']);

    $tests_json = json_encode($assessment['recommended_tests']);
    $stmt->bindParam(":tests", $tests_json);
    $stmt->bindParam(":notes", $assessment['ai_notes']);

    if ($stmt->execute()) {
        http_response_code(200);
        echo json_encode($assessment);
    } else {
        http_response_code(503);
        echo json_encode(["message" => "Unable to save triage record."]);
    }
} else {
    http_response_code(400);
    echo json_encode(["message" => "Incomplete data."]);
}
