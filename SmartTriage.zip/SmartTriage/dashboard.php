<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Live Triage Dashboard - SmartTriage AI</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Dashboard Specific Styles */
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 1.5rem;
            margin-top: 2rem;
        }

        .patient-card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            overflow: hidden;
            transition: transform 0.2s;
            border: 1px solid #eee;
        }

        .patient-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
        }

        .border-red {
            border-top: 5px solid var(--danger-color);
        }

        .border-yellow {
            border-top: 5px solid var(--warning-color);
        }

        .border-green {
            border-top: 5px solid var(--success-color);
        }

        .card-header {
            padding: 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #f0f0f0;
        }

        .patient-name {
            font-weight: 700;
            font-size: 1.1rem;
        }

        .triage-tag {
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            font-size: 0.8rem;
            font-weight: 700;
            text-transform: uppercase;
        }

        .tag-red {
            background: rgba(220, 53, 69, 0.1);
            color: var(--danger-color);
        }

        .tag-yellow {
            background: rgba(255, 193, 7, 0.1);
            color: #ae8604;
        }

        .tag-green {
            background: rgba(40, 167, 69, 0.1);
            color: var(--success-color);
        }

        .card-body {
            padding: 1rem;
        }

        .card-body p {
            margin: 0.5rem 0;
            font-size: 0.9rem;
            color: #555;
        }

        .vital-preview {
            display: flex;
            gap: 1rem;
            margin-top: 0.5rem;
            color: #777;
            font-size: 0.85rem;
        }

        .btn-details {
            width: 100%;
            margin-top: 1rem;
            padding: 0.5rem;
            border: 1px solid var(--primary-color);
            background: white;
            color: var(--primary-color);
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.2s;
        }

        .btn-details:hover {
            background: var(--primary-color);
            color: white;
        }

        .card-footer {
            background: #f8f9fa;
            padding: 0.5rem 1rem;
            font-size: 0.8rem;
            color: #777;
            display: flex;
            justify-content: space-between;
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 2000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(4px);
        }

        .modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 2rem;
            border: 1px solid #888;
            width: 90%;
            max-width: 600px;
            border-radius: 12px;
            position: relative;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .modal-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
            margin-bottom: 1rem;
        }

        .modal-section {
            margin-bottom: 1.5rem;
        }

        .modal-section h4 {
            border-bottom: 1px solid #eee;
            padding-bottom: 0.5rem;
            margin-bottom: 0.5rem;
            color: var(--primary-color);
        }

        .vital-list,
        .test-list {
            list-style: none;
            padding: 0;
            font-size: 0.95rem;
        }

        .vital-list li,
        .test-list li {
            margin-bottom: 0.25rem;
        }
    </style>
</head>

<body>

    <div class="container" style="max-width: 1200px;">
        <header style="display: flex; justify-content: space-between; align-items: center;">
            <div>
                <h1>Live Triage Queue</h1>
                <p>Real-time Patient Monitoring</p>
            </div>
            <div>
                <a href="index.php" class="btn-submit" style="width: auto; padding: 0.5rem 1rem; font-size: 0.9rem; text-decoration: none;">+ New Patient</a>
            </div>
        </header>

        <div id="queue-list" class="dashboard-grid">
            <!-- Patient Cards will be injected here -->
            <div style="grid-column: 1/-1; text-align: center; padding: 2rem; color: #777;">
                Loading queue...
            </div>
        </div>
    </div>

    <!-- Details Modal -->
    <div id="detailsModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2 id="m-name" style="margin-top: 0;"></h2>
            <p id="m-details" style="color: #666;"></p>

            <div class="modal-grid">
                <div class="modal-section">
                    <h4>Contact</h4>
                    <p id="m-contact"></p>
                </div>
                <div class="modal-section">
                    <h4>Triage Assessment</h4>
                    <span id="m-triage" class="triage-badge"></span>
                    <p style="margin-top: 0.5rem;"><strong>Severity Score:</strong> <span id="m-score"></span>/100</p>
                </div>
            </div>

            <div class="modal-section">
                <h4>Description</h4>
                <p><strong>Symptoms:</strong> <span id="m-symptoms"></span></p>
                <p><strong>History:</strong> <span id="m-history"></span></p>
            </div>

            <div class="modal-grid">
                <div class="modal-section">
                    <h4>Vitals</h4>
                    <ul id="m-vitals" class="vital-list"></ul>
                </div>
                <div class="modal-section">
                    <h4>Recommended Tests</h4>
                    <ul id="m-tests" class="test-list"></ul>
                </div>
            </div>

            <div class="modal-section ai-notes">
                <strong><i class="fas fa-robot"></i> AI Notes:</strong>
                <p id="m-notes" style="margin-top: 0.5rem;"></p>
            </div>
        </div>
    </div>

    <script src="assets/js/dashboard.js"></script>
</body>

</html>